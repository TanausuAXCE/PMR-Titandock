# Parámetro obligatorio: Nombre del grupo (SamAccountName)
param(
    [Parameter(Mandatory=$true)]
    [string]$GroupName
)

# Importar módulo AD
try {
    Import-Module ActiveDirectory -ErrorAction Stop
}
catch {
    Write-Host "ERROR: No se pudo importar el módulo ActiveDirectory."
    exit 1
}

# --- Protección Opcional (pero Recomendada) contra Borrado de Grupos Críticos ---
# Lista de SIDs o nombres de grupos críticos que NO se deben borrar desde aquí
$criticalGroups = @(
    "Domain Admins",
    "Enterprise Admins",
    "Schema Admins",
    "Administrators",
    "Users",
    "Guests",
    "Account Operators",
    "Server Operators",
    "Print Operators",
    "Backup Operators",
    "Domain Controllers",
    "Read-only Domain Controllers",
    "Group Policy Creator Owners"
    # Añade otros SIDs o nombres si es necesario, ej: "S-1-5-32-544" para Administrators
)

if ($GroupName -in $criticalGroups) {
    Write-Host "ERROR: No se permite eliminar el grupo crítico '$GroupName' desde esta interfaz."
    exit 1
}
# ---------------------------------------------------------------------------

# Intentar obtener el grupo para verificar que existe
try {
    $group = Get-ADGroup -Identity $GroupName -ErrorAction Stop
}
catch {
    Write-Host "ERROR: Grupo '$GroupName' no encontrado."
    exit 1
}

# Comprobar si es un grupo de sistema (otra capa de protección)
# Los grupos de sistema suelen tener un SID bien conocido que empieza por S-1-5-32 o el atributo isCriticalSystemObject
# $isSystem = $group | Where-Object {$_.SID -like "S-1-5-32-*" -or $_.isCriticalSystemObject -eq $true}
# if ($isSystem) {
#     Write-Host "ERROR: No se permite eliminar el grupo de sistema '$GroupName'."
#     exit 1
# }

# Intentar eliminar el grupo (Confirmación desactivada!)
try {
    Remove-ADGroup -Identity $GroupName -Confirm:$false -ErrorAction Stop
    Write-Host "SUCCESS: Grupo '$GroupName' eliminado correctamente."
    exit 0
}
catch {
    $errorMessage = $_.Exception.Message
    # Comprobar si el error es por permisos
    if ($errorMessage -like "*Insufficient access rights*") {
         Write-Host "ERROR: Permisos insuficientes para eliminar el grupo '$GroupName'."
    } else {
        Write-Host "ERROR: Fallo al eliminar el grupo '$GroupName'. Detalles: $errorMessage"
    }
    exit 1
}