# Parámetro obligatorio: Nombre del grupo
param(
    [Parameter(Mandatory=$true)]
    [string]$GroupName
)

# Importar módulo AD
try {
    Import-Module ActiveDirectory -ErrorAction Stop
}
catch {
    Write-Host "ERROR: No se pudo importar el módulo ActiveDirectory."
    exit 1
}

# Intentar obtener los miembros del grupo
try {
    # Obtener los miembros y seleccionar solo su nombre (SamAccountName)
    # Get-ADGroupMember puede devolver usuarios, grupos y equipos. Usamos Name aquí.
    # Podrías usar SamAccountName si lo prefieres.
    $members = Get-ADGroupMember -Identity $GroupName -ErrorAction Stop | Select-Object -ExpandProperty Name

    # Imprimir cada miembro en una nueva línea
    if ($members) {
        $members | ForEach-Object { Write-Host $_ }
    }
    # Si no hay miembros, no imprimirá nada, PHP devolverá []

    # Aunque no imprima miembros, la operación de búsqueda fue exitosa
    # Podríamos añadir una línea SUCCESS si quisiéramos, pero no es estrictamente necesaria aquí
    # Write-Host "SUCCESS: Búsqueda de miembros completada."

    exit 0 # Éxito (incluso si no hay miembros)
}
catch {
    # Capturar errores, como grupo no encontrado
    $errorMessage = $_.Exception.Message
     if ($errorMessage -like "*Cannot find an object with identity*") {
         Write-Host "ERROR: No se encontró el grupo '$GroupName'."
     }
     elseif ($errorMessage -like "*Insufficient access rights*") {
         Write-Host "ERROR: Permisos insuficientes para leer los miembros del grupo '$GroupName'."
     }
     else {
        Write-Host "ERROR: Fallo al obtener miembros del grupo '$GroupName'. Detalles: $errorMessage"
     }
    exit 1 # Error
}