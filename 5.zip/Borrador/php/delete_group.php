<?php
header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Error desconocido al eliminar grupo.'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $groupName = $_POST['group_name'] ?? null;

    if (empty($groupName)) {
        $response['message'] = 'Error: Nombre del grupo no proporcionado.';
    } else {
        // --- Ejecutar PowerShell ---
        $powershell_script_path = __DIR__ . "/../ps1/delete_group.ps1"; // ¡NUEVO SCRIPT PS1!
        $execution_policy = "-ExecutionPolicy Unrestricted";

        $psGroupName_arg = escapeshellarg($groupName);

        $command = "powershell.exe {$execution_policy} -NoProfile -File \"{$powershell_script_path}\" -GroupName {$psGroupName_arg}";
        $output = shell_exec($command . " 2>&1");
        error_log("SALIDA BRUTA de delete_group.ps1 para '{$groupName}': " . $output); // Log para depuración

        // --- Interpretar resultado ---
        if ($output !== null && stripos($output, 'SUCCESS:') !== false) {
            $response['success'] = true;
            preg_match('/SUCCESS:(.*)/i', $output, $matches);
            $response['message'] = trim($matches[1] ?? "Grupo '$groupName' eliminado.");

        } elseif ($output !== null && stripos($output, 'ERROR:') !== false) {
            $response['success'] = false;
             preg_match('/ERROR:(.*)/i', $output, $matches);
             $response['message'] = trim($matches[1] ?? "Error al eliminar grupo '$groupName'.");
        } else {
            $response['success'] = false;
            $response['message'] = "Respuesta inesperada del script al eliminar grupo '$groupName'. Salida: " . ($output ?: '(Sin salida)');
        }
         // $response['debug_command'] = $command;
         // $response['debug_output'] = $output;
    }

} else {
    $response['message'] = 'Error: Método POST requerido.';
}

echo json_encode($response);
exit;
?>