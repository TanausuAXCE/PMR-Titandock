<?php
$command = "powershell.exe -ExecutionPolicy Bypass -File ../ps1/get_users.ps1";
$output = shell_exec($command);
header('Content-Type: application/json');
echo $output;
?>
