<?php
// No establecer Content-Type aquí, se hará después de verificar errores

$response = []; // Respuesta por defecto

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $groupName = $_POST['group_name'] ?? null;

    if (empty($groupName)) {
        $response = ['error' => 'Nombre del grupo no proporcionado.'];
        header('HTTP/1.1 400 Bad Request'); // Error de cliente
    } else {
        // --- Ejecutar PowerShell ---
        $powershell_script_path = __DIR__ . "/../ps1/get_group_members.ps1"; // ¡NUEVO SCRIPT PS1!
        $execution_policy = "-ExecutionPolicy Unrestricted";

        $psGroupName_arg = escapeshellarg($groupName);

        $command = "powershell.exe {$execution_policy} -NoProfile -File \"{$powershell_script_path}\" -GroupName {$psGroupName_arg}";
        $output = shell_exec($command . " 2>&1");
        error_log("SALIDA BRUTA de get_group_members.ps1 para '{$groupName}': " . $output);

        // --- Procesar resultado ---
        $members = [];
        $error_detected = false;

        if ($output === null) {
            $response = ['error' => 'Error interno del servidor al ejecutar script de miembros.'];
            $error_detected = true;
            if (!headers_sent()) header('HTTP/1.1 500 Internal Server Error');
        } else {
            $lines = preg_split('/\r\n|\r|\n/', trim($output));
            foreach ($lines as $line) {
                $trimmed_line = trim($line);
                if (stripos($trimmed_line, 'ERROR:') !== false) {
                    preg_match('/ERROR:(.*)/i', $trimmed_line, $matches);
                    $response = ['error' => trim($matches[1] ?? 'Error detectado en script PowerShell.')];
                    $error_detected = true;
                     if (!headers_sent()) header('HTTP/1.1 500 Internal Server Error'); // Error del lado del servidor si PS falla
                    break;
                }
                 // Ignorar la línea SUCCESS si existe (solo queremos los nombres)
                 if (stripos($trimmed_line, 'SUCCESS:') !== false) {
                    continue;
                 }
                if (!empty($trimmed_line)) {
                    $members[] = $trimmed_line;
                }
            }
            // Si no hubo error, la respuesta es la lista de miembros (puede estar vacía)
            if (!$error_detected) {
                $response = $members;
            }
        }
    }
} else {
    $response = ['error' => 'Método POST requerido.'];
     if (!headers_sent()) header('HTTP/1.1 405 Method Not Allowed'); // Error de método
}

// --- Codificar y Enviar ---
// Establecer cabecera JSON antes de enviar la respuesta
if (!headers_sent()) {
    header('Content-Type: application/json');
}

$json_output = json_encode($response, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_IGNORE);

if ($json_output === false) {
    // Falló json_encode (ya no debería pasar con JSON_INVALID_UTF8_IGNORE, pero por si acaso)
    $json_error_code = json_last_error();
    $json_error_msg = json_last_error_msg();
    error_log("ERROR: json_encode falló en get_group_members.php. Código: {$json_error_code}, Mensaje: {$json_error_msg}");
    // Si ya se envió 500, no podemos cambiarlo, pero si no, lo ponemos
    if (!headers_sent()) {
        header('HTTP/1.1 500 Internal Server Error');
        header('Content-Type: application/json'); // Asegurar cabecera JSON
    }
    // Enviar un JSON de error genérico si la codificación falló
    echo json_encode(['error' => "Fallo al codificar la respuesta JSON (Error code: {$json_error_code})"]);
} else {
    // Enviar la respuesta (puede ser el array de miembros o un array con ['error'])
    echo $json_output;
}
exit;
?>