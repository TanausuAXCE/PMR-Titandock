<?php
// Establecer cabecera JSON SIEMPRE al principio
// PERO si vamos a enviar un error 500 más tarde, esta cabecera podría ser ignorada
// o causar conflictos. Es mejor establecerla solo si tenemos éxito.
// header('Content-Type: application/json'); <-- Comentado/Eliminado por ahora

// Respuesta por defecto en caso de error
$response = ['error' => 'Error desconocido al procesar la solicitud.']; // Cambiado a 'error' para consistencia

// Verificar que el método sea POST - ¡ERROR! get_groups debería ser GET
// Corregido para permitir GET (o cualquier método, ya que solo lee datos)
// if ($_SERVER["REQUEST_METHOD"] == "POST") { ... } <-- Eliminado chequeo de método

// --- Ejecutar PowerShell ---
$powershell_script_path = __DIR__ . "/../ps1/get_groups.ps1";
$execution_policy = "-ExecutionPolicy Unrestricted"; // O la necesaria

// Construir y ejecutar comando
$command = "powershell.exe {$execution_policy} -NoProfile -File \"{$powershell_script_path}\"";
$output = shell_exec($command . " 2>&1"); // Capturar salida y errores
error_log("SALIDA BRUTA de get_groups.ps1: " . $output); // Log existente

// --- Procesar resultado ---
$groups = []; // Inicializa groups aquí
$error_detected = false; // Flag para error detectado

if ($output === null) {
    // Error grave al ejecutar shell_exec
    $response = ['error' => 'Error interno del servidor al ejecutar el script de PowerShell.'];
    $error_detected = true;
    // Establecer código de estado 500 aquí también
    if (!headers_sent()) { // Evitar error si las cabeceras ya se enviaron
        header('HTTP/1.1 500 Internal Server Error');
        header('Content-Type: application/json'); // Enviar cabecera JSON con el error
    }
} else {
    // Limpiar la salida y convertirla en un array
    // Usar preg_split para manejar \n y \r\n
    $lines = preg_split('/\r\n|\r|\n/', trim($output));
    foreach ($lines as $line) {
        $trimmed_line = trim($line);
        // Si la línea contiene "ERROR:", consideramos que hubo un fallo
        if (stripos($trimmed_line, 'ERROR:') !== false) {
            $response = ['error' => 'Error detectado en script PowerShell: ' . $trimmed_line];
            $groups = []; // Vaciar grupos si encontramos error
            $error_detected = true; // Marcar que hubo error
             // Establecer código de estado 500 aquí también
             if (!headers_sent()) {
                header('HTTP/1.1 500 Internal Server Error');
                header('Content-Type: application/json'); // Enviar cabecera JSON con el error
             }
            break; // Salir del bucle
        }
        // Si la línea no está vacía y no es un error, la añadimos
        if (!empty($trimmed_line)) {
            $groups[] = $trimmed_line;
        }
    }
    // Si no hubo error explícito durante el parseo, la respuesta es la lista de grupos
    if (!$error_detected) {
        $response = $groups; // Asigna el array de grupos directamente
    }
}

// --- Codificar y Enviar ---

// Log del array final (como ya tenías)
error_log("RESPUESTA FINAL get_groups.php antes de JSON: " . print_r($response, true));

// Intentar codificar a JSON solo si no hemos detectado un error ANTES de json_encode
if (!$error_detected) {
    $json_output = json_encode($response, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_IGNORE); // Añadida opción para ignorar UTF8 inválido

    // Verificar si json_encode falló
    if ($json_output === false) {
        // Hubo un error al codificar! Registrarlo.
        $json_error_code = json_last_error();
        $json_error_msg = json_last_error_msg();
        error_log("ERROR: json_encode falló. Código: {$json_error_code}, Mensaje: {$json_error_msg}");

        // Preparar respuesta de error JSON
        $response = ['error' => "Fallo al codificar la respuesta JSON (Error code: {$json_error_code})"];
        $error_detected = true; // Marcar error
        // Establecer código de estado 500
        if (!headers_sent()) {
             header('HTTP/1.1 500 Internal Server Error');
             header('Content-Type: application/json'); // Enviar cabecera JSON con el error
        }

    } else {
        // json_encode tuvo éxito. Establecer cabecera y enviar.
         if (!headers_sent()) {
            header('Content-Type: application/json'); // Cabecera JSON solo si todo OK hasta aquí
         }
        echo $json_output;
        exit; // Salir después de enviar con éxito
    }
}

// Si llegamos aquí, significa que hubo un error detectado *antes* o *durante* json_encode
// El código de estado 500 y la cabecera JSON ya deberían haberse establecido.
// Enviamos el $response que contiene el mensaje de error.
// Asegurarse de que $response sea un array asociativo para json_encode
if (!is_array($response) || !isset($response['error'])) {
     $response = ['error' => 'Error inesperado en el servidor.']; // Fallback
      if (!headers_sent()) { // Asegurarse de enviar cabecera 500 si no se hizo antes
           header('HTTP/1.1 500 Internal Server Error');
           header('Content-Type: application/json');
       }
}
echo json_encode($response); // Enviar el array de error
exit;
?>