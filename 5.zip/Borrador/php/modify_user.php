<?php
header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Error desconocido.'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'] ?? null;
    $newPassword = $_POST['password'] ?? null;
    $newDescription = $_POST['description'] ?? null;
    $newGroup = $_POST['group'] ?? null; // Este no está en $allowedProperties del PS1

    if (empty($username)) {
        $response['message'] = 'Error: Nombre de usuario obligatorio.';
        echo json_encode($response);
        exit;
    }

    // --- Ejecución del PowerShell MODIFICADO ---
    $powershell_script_path = __DIR__ . "/../ps1/modify_user.ps1";
    $execution_policy = "-ExecutionPolicy Unrestricted"; // O la necesaria

    $final_output_log = '';
    $overall_success = true;
    $messages = []; // Para acumular mensajes

    // Mapea campos del formulario a propiedades de AD permitidas en el PS1
    $attributes_to_update = [];
    if ($newDescription !== null) { $attributes_to_update['Description'] = $newDescription; }
    // AÑADE AQUÍ OTROS CAMPOS DEL FORMULARIO QUE ESTÉN EN $allowedProperties del PS1
    // Ejemplo: si tuvieras 'title' en el form:
    // $newTitle = $_POST['title'] ?? null;
    // if ($newTitle !== null) { $attributes_to_update['Title'] = $newTitle; }


    // Llama al script PS1 por cada atributo a cambiar
    foreach ($attributes_to_update as $property => $newValue) {
        $psUsername_arg = escapeshellarg($username);
        $psProperty_arg = escapeshellarg($property);
        $psNewValue_arg = escapeshellarg($newValue);

        // Usar -File es más robusto para pasar rutas y argumentos
        $command = "powershell.exe {$execution_policy} -NoProfile -File \"{$powershell_script_path}\" -SamAccountName {$psUsername_arg} -PropertyName {$psProperty_arg} -NewValue {$psNewValue_arg}";

        $output = shell_exec($command . " 2>&1"); // Captura salida y errores
        $final_output_log .= "Intento cambio {$property}:\nComando: {$command}\nSalida:\n{$output}\n---\n";

        // Interpreta la salida del PS1 modificado
        if ($output === null || stripos($output, 'ERROR:') !== false) {
            $overall_success = false;
            // Intenta extraer el mensaje de error del PS1 si es posible
            $error_detail = $output;
            if (preg_match('/ERROR:(.*)/i', $output ?? '', $matches)) {
                $error_detail = trim($matches[1]);
            }
            $messages[] = "Fallo al actualizar '{$property}': " . ($error_detail ?: '(Sin salida detallada)');
            // Decide si parar al primer error o intentar todos los campos
            // break; // Descomenta para parar al primer error
        } elseif (stripos($output, 'SUCCESS:') !== false) {
             $messages[] = "Propiedad '{$property}' actualizada.";
        } else {
            // Salida inesperada del script PS1
            $overall_success = false; // Considera esto un fallo
            $messages[] = "Respuesta inesperada al actualizar '{$property}'. Salida: " . ($output ?: '(Sin salida)');
        }
    }

    // --- Manejo de Contraseña y Grupo (No implementados en el PS1 actual) ---
    if (!empty($newPassword)) {
        $messages[] = "Nota: El cambio de contraseña no se realizó (no implementado en script PS1).";
        // Considera $overall_success = false; si esto es un fallo crítico para el usuario
    }
    if (!empty($newGroup)) {
        $messages[] = "Nota: El cambio de grupo no se realizó (no implementado en script PS1).";
         // Considera $overall_success = false;
    }

    // --- Respuesta Final ---
    $response['success'] = $overall_success;
    $response['message'] = implode("\n", $messages); // Une todos los mensajes
    if (!$overall_success) {
        $response['debug_log'] = $final_output_log; // Opcional: enviar log en caso de error
    }


} else {
    $response['message'] = 'Error: Método POST requerido.';
}

echo json_encode($response);
exit;
?>