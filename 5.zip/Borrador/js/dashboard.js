document.addEventListener("DOMContentLoaded", function () {
    // Cargar el nombre del usuario desde localStorage
    const userName = localStorage.getItem("user");  // Suponiendo que guardamos el nombre del usuario como "user"
    
    // Si hay un nombre de usuario en el almacenamiento local, lo mostramos en el botón
    if (userName) {
        const userBtn = document.getElementById("user-name-btn");
        userBtn.textContent = userName;  // Mostrar el nombre del usuario en el botón
    }

    // Theme switcher
    const themeSwitch = document.getElementById("theme-switch");
    const body = document.body;

    themeSwitch.addEventListener("change", function () {
        body.classList.toggle("light-mode", themeSwitch.checked);
    });

    // User dropdown toggle
    const userBtn = document.getElementById("user-name-btn");
    const dropdown = document.getElementById("user-dropdown");

    userBtn.addEventListener("click", function () {
        dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    });
});
