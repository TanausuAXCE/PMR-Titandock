document.addEventListener("DOMContentLoaded", function () {
    const termsCheckbox = document.getElementById("terms");
    const registerBtn = document.getElementById("register-btn");

    termsCheckbox.addEventListener("change", function () {
        registerBtn.disabled = !this.checked;
    });
});

// Funciones para mostrar el formulario de login o registro
function showLogin() {
    document.getElementById("login-form").classList.remove("hidden");
    document.getElementById("register-form").classList.add("hidden");
    document.getElementById("login-tab").classList.add("active");
    document.getElementById("register-tab").classList.remove("active");
}

function showRegister() {
    document.getElementById("login-form").classList.add("hidden");
    document.getElementById("register-form").classList.remove("hidden");
    document.getElementById("login-tab").classList.remove("active");
    document.getElementById("register-tab").classList.add("active");
}

// Función para el inicio de sesión
function login() {
    let user = document.getElementById("login-user").value;
    let pass = document.getElementById("login-pass").value;
    let rememberMe = document.getElementById("remember-me").checked;

    let storedUser = localStorage.getItem("user");
    let storedPass = localStorage.getItem("pass");

    if (user === storedUser && pass === storedPass) {
        if (rememberMe) {
            localStorage.setItem("rememberMe", "true");
        } else {
            localStorage.removeItem("rememberMe");
        }
        alert("Inicio de sesión exitoso");
        window.location.href = "../pages/dashboard.html";
    } else {
        alert("Usuario o contraseña incorrectos");
    }
}

// Función para el registro de usuario
function register() {
    let user = document.getElementById("register-user").value;
    let email = document.getElementById("register-email").value;
    let pass = document.getElementById("register-pass").value;
    let termsAccepted = document.getElementById("terms").checked;

    if (user && email && pass && termsAccepted) {
        localStorage.setItem("user", user);
        localStorage.setItem("pass", pass);
        alert("Registro exitoso. Ahora puedes iniciar sesión.");
        showLogin();
    } else {
        alert("Por favor, completa todos los campos y acepta los términos.");
    }
}
