<?php
session_start(); // Inicia la sesión

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    header("Location: ../pages/login.php"); // Redirige si no está autenticado
    exit();
}

$username = $_SESSION['usuario']; // Obtén el nombre del usuario desde la sesión
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TitanDock - Dashboard</title>
    <link rel="stylesheet" href="../css/dashboard.css">
    <style>
        /* --- Tus estilos CSS existentes --- */
        body, html { margin: 0; padding: 0; height: 100%; display: flex; flex-direction: column; font-family: sans-serif; /* Añadido */ }
        main { flex: 1; overflow: auto; padding-top: 60px; /* Ajusta */ }
        iframe { width: 100%; height: calc(100vh - 60px); border: none; }
        .action-box { width: 300px; padding: 20px; margin: 20px auto; background-color: #f4f4f4; border-radius: 10px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); text-align: center; }
        .action-box h3 { margin-bottom: 15px; font-size: 18px; color: #333; }
        .action-box button { padding: 10px 20px; font-size: 16px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s; }
        .action-box button:hover { background-color: #0056b3; }

        /* Estilos Modal (existentes y nuevos mínimos) */
        .modal { display: none; position: fixed; z-index: 1000; left: 0; top: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); overflow: auto; }
        .modal-content { background-color: #fff; margin: 10% auto; padding: 20px; border-radius: 8px; width: 80%; max-width: 600px; position: relative; box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        .close-btn { position: absolute; top: 10px; right: 15px; font-size: 30px; color: #aaa; cursor: pointer; line-height: 1; }
        .close-btn:hover { color: #000; }
        .modal-content form { margin-top: 15px; }
        .modal-content label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }
        .modal-content input[type="text"],
        .modal-content input[type="password"],
        .modal-content select { width: calc(100% - 22px); padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; font-size: 16px; box-sizing: border-box; }
        .modal-content button[type="button"] { padding: 10px 20px; font-size: 16px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s; margin-top: 10px; }
        .modal-content button[type="button"]:hover { background-color: #0056b3; }
        #create-user-message, #edit-user-message, #create-group-message, #delete-user-message, #delete-group-message { margin-top: 15px; font-weight: bold; display: none; padding: 8px; border-radius: 4px; }
        [id$="-message"][style*="color: green"] { background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; display: block; }
        [id$="-message"][style*="color: red"] { background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; display: block; }
        [id$="-message"][style*="color: rgb(85"] { background-color: #e2e3e5; border: 1px solid #d6d8db; color: #383d41; display: block; }
        [id$="-message"]:not([style*="color"]) { background-color: #e2e3e5; border: 1px solid #d6d8db; color: #383d41; display: block; }

        ul { list-style-type: none; padding: 0; margin-top: 15px; }
        li { padding: 8px 0; font-size: 16px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; }
        li:last-child { border-bottom: none; }
        li button { padding: 5px 10px; font-size: 14px; color: white; border: none; border-radius: 4px; cursor: pointer; margin-left: 10px; transition: background-color 0.3s;}
        li button[onclick*="showEditForm"] { background-color: #28a745; }
        li button[onclick*="showEditForm"]:hover { background-color: #218838; }
        li button[onclick*="confirmUserDeletion"],
        li button[onclick*="confirmGroupDeletion"] { background-color: #dc3545; }
        li button[onclick*="confirmUserDeletion"]:hover,
        li button[onclick*="confirmGroupDeletion"]:hover { background-color: #c82333; }

        /* === NUEVO CSS PARA BOTÓN "VER MIEMBROS" === */
         .modal-content li button.view-members-btn {
             background-color: #17a2b8; /* Color Cian/Info */
         }
          .modal-content li button.view-members-btn:hover {
              background-color: #138496;
          }
        /* ========================================= */

        /* Estilos Modo Oscuro (existentes) */
        body.dark-mode { background-color: #121212; color: #ffffff; } body.dark-mode .action-box { background-color: #333333; box-shadow: 0 4px 8px rgba(255, 255, 255, 0.1); } body.dark-mode .action-box h3 { color: #eeeeee; }
        body.dark-mode .modal .modal-content { background-color: #333333; color: #ffffff; } body.dark-mode .modal .close-btn { color: #aaaaaa; } body.dark-mode .modal .close-btn:hover { color: #ffffff; }
        body.dark-mode .modal-content label { color: #dddddd; }
        body.dark-mode .modal-content input[type="text"], body.dark-mode .modal-content input[type="password"], body.dark-mode .modal-content select { background-color: #444444; border-color: #666666; color: #ffffff; }
        body.dark-mode li { border-bottom-color: #444444; }
        body.dark-mode [id$="-message"][style*="color: green"] { background-color: #2a5c34; border-color: #3a7c44; color: #d1e7dd; } body.dark-mode [id$="-message"][style*="color: red"] { background-color: #721c24; border-color: #842029; color: #f8d7da; } body.dark-mode [id$="-message"]:not([style*="color"]) { background-color: #6c757d; border-color: #adb5bd; color: #dee2e6; }

        /* Estilos Modo Claro (existentes) */
        body { background-color: #ffffff; color: #333333; } .modal .modal-content { background-color: #ffffff; color: #333333; } .modal .close-btn { color: #aaa; } .modal .close-btn:hover { color: #000; }
        .modal-content label { color: #555; } .modal-content input[type="text"], .modal-content input[type="password"], .modal-content select { background-color: #ffffff; border-color: #ccc; color: #333333; }
        li { border-bottom-color: #eee; }

        /* Dropdown y Tema (existentes) */
        .dropdown-content { display: none; position: absolute; background-color: #f9f9f9; min-width: 160px; box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); z-index: 1; right: 0; } .dropdown-content a { color: black; padding: 12px 16px; text-decoration: none; display: block; } .dropdown-content a:hover { background-color: #f1f1f1; } .show { display: block; }
        body.dark-mode .dropdown-content { background-color: #444; } body.dark-mode .dropdown-content a { color: #eee; } body.dark-mode .dropdown-content a:hover { background-color: #555; }
        .theme-toggle { display: flex; align-items: center; } .switch { position: relative; display: inline-block; width: 50px; height: 24px; } .switch input { opacity: 0; width: 0; height: 0; } .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 24px; } .slider:before { position: absolute; content: ""; height: 18px; width: 18px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; } input:checked + .slider { background-color: #007bff; } input:checked + .slider:before { transform: translateX(26px); }
        body.dark-mode .slider { background-color: #6c757d; } body.dark-mode input:checked + .slider { background-color: #007bff; } body.dark-mode .slider:before { background-color: #f8f9fa; }

    </style>
</head>
<body class="<?php echo isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark' ? 'dark-mode' : ''; ?>">
    <header>
        <nav class="navbar">
            <div class="logo" id="home-link" style="cursor: pointer;">
                <img src="../assets/logo.png" alt="Logo TitanDock" id="logo">
                <span class="logo-text">TitanDock</span>
            </div>
            <ul class="navbar-right">
                <li class="theme-toggle">
                    <label for="theme-switch" class="switch">
                        <input type="checkbox" id="theme-switch" <?php echo isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark' ? 'checked' : ''; ?>>
                        <span class="slider"></span>
                    </label>
                </li>
                <li><a href="#" id="prometheus-link">Prometheus</a></li>
                <li><a href="#" id="grafana-link">Grafana</a></li>
                <li class="user-info">
                     <button id="user-name-btn" class="user-btn">
                        <?php echo htmlspecialchars($username); ?> &#9662; </button>
                    <div id="user-dropdown" class="dropdown-content">
                        <a href="../php/logout.php">Cerrar Sesión</a>
                        </div>
                </li>
            </ul>
        </nav>
    </header>

    <main id="main-content">
        <section class="dashboard-content" id="dashboard-home">
             <h2>Bienvenido, <?php echo htmlspecialchars($username); ?>!</h2>
             <p>Aquí puedes gestionar tu aplicación y visualizar métricas.</p>
             <div class="action-box">
                 <h3>Crear usuario en el dominio</h3>
                 <button class="action-btn" data-action="create">Crear usuario</button>
             </div>
             <div class="action-box">
                 <h3>Ver usuarios en el dominio</h3>
                 <button class="action-btn" data-action="view">Ver usuarios</button>
             </div>
             <div class="action-box">
                 <h3>Modificar usuario en el dominio</h3>
                 <button class="action-btn" data-action="modify">Modificar usuario</button>
             </div>
             <div class="action-box">
                 <h3>Crear grupo en el dominio</h3>
                 <button class="action-btn" data-action="create-group">Crear grupo</button>
             </div>
             <div class="action-box">
                 <h3>Eliminar usuario del dominio</h3>
                 <button class="action-btn" data-action="delete-user" style="background-color: #dc3545; border-color: #dc3545;">Eliminar usuario</button>
             </div>
             <div class="action-box">
                 <h3>Ver grupos del dominio</h3>
                 <button class="action-btn" data-action="view-groups">Ver grupos</button>
             </div>
              <div class="action-box">
                 <h3>Eliminar grupo del dominio</h3>
                 <button class="action-btn" data-action="delete-group" style="background-color: #dc3545; border-color: #dc3545;">Eliminar grupo</button>
             </div>
        </section> </main>

    <script>
        // --- Funciones Auxiliares (Cookies, DarkMode, Modales) ---
        function setCookie(name, value, days) { const d = new Date(); d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000)); const expires = "expires=" + d.toUTCString(); document.cookie = name + "=" + value + ";" + expires + ";path=/"; }
        function getCookie(name) { const dc = decodeURIComponent(document.cookie); const ca = dc.split(';'); const n = name + "="; for(let i = 0; i <ca.length; i++) { let c = ca[i].trim(); if (c.indexOf(n) == 0) { return c.substring(n.length, c.length); } } return ""; }
        function isDarkMode() { return document.body.classList.contains('dark-mode'); }
        function closeModal(modalId) { const modal = document.getElementById(modalId); if (modal) { modal.style.display = "none"; modal.remove(); } }
        function showModalMessage(modalId, message, isSuccess) { const msgId = modalId.replace('-modal', '-message'); const div = document.getElementById(msgId); if(div) { div.textContent = message; div.style.color = isSuccess ? 'green' : 'red'; div.style.display = 'block'; } else { console.warn("Msg div not found:", msgId); alert(message); } }
        function clearModalMessage(modalId) { const msgId = modalId.replace('-modal', '-message'); const div = document.getElementById(msgId); if (div) { div.innerHTML = ''; div.style.display = 'none'; } const listId = modalId.replace('-message', '-selection-list'); /* Busca el ID de la lista si existe */ const listDiv = document.getElementById(listId); if(listDiv && listDiv.style.display==='none') listDiv.style.display = 'block'; /* Re-muestra lista si se ocultó */ }


        // --- Funciones para Modales Específicos ---
        // (Usamos showListModal que está definida al final de tu código)

        // Modal CREAR USUARIO (existente)
        function showCreateUserModal() { const id='create-user-modal'; closeModal(id); const html = `<div id="${id}" class="modal ${isDarkMode()?'dark-mode':''}"><div class="modal-content"><span class="close-btn" onclick="closeModal('${id}')">&times;</span><h3>Crear Nuevo Usuario</h3><form id="create-user-form" onsubmit="return false;"><label for="new_username">Nombre de usuario:</label><input type="text" id="new_username" name="username" required><label for="new_password">Contraseña:</label><input type="password" id="new_password" name="password" required autocomplete="new-password"><label for="new_group">Grupo (opcional):</label><input type="text" id="new_group" name="group"><label for="new_ou">OU (opcional):</label><input type="text" id="new_ou" name="ou"><button type="button" onclick="submitCreateUserForm()">Crear Usuario</button></form><div id="create-user-message"></div></div></div>`; document.body.insertAdjacentHTML('beforeend', html); document.getElementById(id).style.display="block"; }
        // Modal MODIFICAR USUARIO (Selección) (existente)
        function showModifyUserModal(users) { const id='modify-user-modal'; closeModal(id); let list='<ul>'; if(users && users.length>0) { users.forEach(u => { const s=u.replace(/</g,"&lt;"); const e=s.replace(/'/g,"\\'").replace(/"/g,'&quot;'); list+=`<li>${s} <button onclick="showEditUserForm('${e}')">Modificar</button></li>`; }); } else { list+='<li>No hay usuarios.</li>'; } list+='</ul>'; const html=`<div id="${id}" class="modal ${isDarkMode()?'dark-mode':''}"><div class="modal-content"><span class="close-btn" onclick="closeModal('${id}')">&times;</span><h3>Seleccionar usuario a modificar</h3><div id="user-selection-list">${list}</div></div></div>`; document.body.insertAdjacentHTML('beforeend', html); document.getElementById(id).style.display="block"; }
        // Modal MODIFICAR USUARIO (Formulario Edición) (existente)
        function showEditUserForm(username) { const id='modify-user-modal'; const modal = document.getElementById(id); if(!modal) return; const formHtml = `<form id="edit-user-form" onsubmit="return false;"><input type="hidden" name="username" value="${username}"><label for="edit_password">Nueva Contraseña (no cambiar si vacío):</label><input type="password" id="edit_password" name="password" autocomplete="new-password"><label for="edit_description">Descripción:</label><input type="text" id="edit_description" name="description"><label for="edit_group">Grupo Principal (opcional):</label><input type="text" id="edit_group" name="group"><button type="button" onclick="submitEditUserForm()">Guardar Cambios</button></form><div id="edit-user-message"></div>`; const content = modal.querySelector('.modal-content'); if(content) { const closeBtn = content.querySelector('.close-btn').outerHTML; content.innerHTML = `${closeBtn}<h3>Modificar Usuario: ${username.replace(/</g,"&lt;")}</h3>${formHtml}`; } }
        // Modal CREAR GRUPO (existente)
        function showCreateGroupModal() { const id='create-group-modal'; closeModal(id); const html = `<div id="${id}" class="modal ${isDarkMode()?'dark-mode':''}"><div class="modal-content"><span class="close-btn" onclick="closeModal('${id}')">&times;</span><h3>Crear Nuevo Grupo</h3><form id="create-group-form" onsubmit="return false;"><label for="new_group_name">Nombre Grupo (SamAccountName):</label><input type="text" id="new_group_name" name="group_name" required><label for="new_group_scope">Ámbito:</label><select id="new_group_scope" name="group_scope" required><option value="DomainLocal">Local Dominio</option><option value="Global" selected>Global</option><option value="Universal">Universal</option></select><label for="new_group_category">Tipo:</label><select id="new_group_category" name="group_category" required><option value="Security" selected>Seguridad</option><option value="Distribution">Distribución</option></select><label for="new_group_description">Descripción (opcional):</label><input type="text" id="new_group_description" name="description"><label for="new_group_path">Ruta OU (opcional):</label><input type="text" id="new_group_path" name="path" placeholder="Default si vacío"><button type="button" onclick="submitCreateGroupForm()">Crear Grupo</button></form><div id="create-group-message"></div></div></div>`; document.body.insertAdjacentHTML('beforeend', html); document.getElementById(id).style.display="block"; }
        // Modal ELIMINAR USUARIO (Selección) (existente)
        function showDeleteUserSelectionModal(users) { const id='delete-user-modal'; closeModal(id); let list='<ul>'; if(users && users.length>0) { users.forEach(u => { const s=u.replace(/</g,"&lt;"); const e=s.replace(/'/g,"\\'").replace(/"/g,'&quot;'); list+=`<li>${s} <button style="background-color:#dc3545;" onclick="confirmUserDeletion('${e}')">Eliminar</button></li>`; }); } else { list+='<li>No hay usuarios.</li>'; } list+='</ul>'; const html=`<div id="${id}" class="modal ${isDarkMode()?'dark-mode':''}"><div class="modal-content"><span class="close-btn" onclick="closeModal('${id}')">&times;</span><h3>Seleccionar usuario a ELIMINAR</h3><p style="color: red; font-weight: bold;">Atención: Acción permanente.</p><div id="user-delete-selection-list">${list}</div><div id="delete-user-message"></div></div></div>`; document.body.insertAdjacentHTML('beforeend', html); document.getElementById(id).style.display="block"; }
        // Modal ELIMINAR GRUPO (Selección) (existente)
        function showDeleteGroupSelectionModal(groups) { const id='delete-group-modal'; closeModal(id); let list='<ul>'; if(groups && groups.length>0) { groups.forEach(g => { const s=g.replace(/</g,"&lt;"); const e=s.replace(/'/g,"\\'").replace(/"/g,'&quot;'); list+=`<li>${s} <button style="background-color:#dc3545;" onclick="confirmGroupDeletion('${e}')">Eliminar</button></li>`; }); } else { list+='<li>No hay grupos.</li>'; } list+='</ul>'; const html=`<div id="${id}" class="modal ${isDarkMode()?'dark-mode':''}"><div class="modal-content"><span class="close-btn" onclick="closeModal('${id}')">&times;</span><h3>Seleccionar grupo a ELIMINAR</h3><p style="color: red; font-weight: bold;">Atención: Puede afectar permisos.</p><div id="group-delete-selection-list">${list}</div><div id="delete-group-message"></div></div></div>`; document.body.insertAdjacentHTML('beforeend', html); document.getElementById(id).style.display="block"; }
        // Confirmación Eliminar Usuario (existente)
        function confirmUserDeletion(username) { const id='delete-user-modal'; const div=document.getElementById('delete-user-message'); if(!div) return; const safeHtml=username.replace(/</g,"&lt;"); const safeJs=username.replace(/'/g,"\\'").replace(/"/g,'&quot;'); div.innerHTML = `<p><strong>¿Estás SEGURO de eliminar a '${safeHtml}'?</strong></p><p style="color:red;"><strong>¡NO SE PUEDE DESHACER!</strong></p><button type="button" style="background-color:#dc3545;color:white;" onclick="submitDeleteUser('${safeJs}')">Sí, Eliminar</button> <button type="button" style="background-color:#6c757d;color:white;margin-left:10px;" onclick="clearModalMessage('${id}')">Cancelar</button>`; div.style.color='red'; div.style.display='block'; const listDiv = document.getElementById('user-delete-selection-list'); if(listDiv) listDiv.style.display = 'none'; }
        // Confirmación Eliminar Grupo (existente)
        function confirmGroupDeletion(groupName) { const id='delete-group-modal'; const div=document.getElementById('delete-group-message'); if(!div) return; const safeHtml=groupName.replace(/</g,"&lt;"); const safeJs=groupName.replace(/'/g,"\\'").replace(/"/g,'&quot;'); div.innerHTML = `<p><strong>¿Estás SEGURO de eliminar el grupo '${safeHtml}'?</strong></p><p style="color:red;"><strong>¡Puede afectar permisos!</strong></p><button type="button" style="background-color:#dc3545;color:white;" onclick="submitDeleteGroup('${safeJs}')">Sí, Eliminar</button> <button type="button" style="background-color:#6c757d;color:white;margin-left:10px;" onclick="clearModalMessage('${id}')">Cancelar</button>`; div.style.color='red'; div.style.display='block'; const listDiv = document.getElementById('group-delete-selection-list'); if(listDiv) listDiv.style.display = 'none'; }


        // --- Funciones AJAX (Fetch) ---
        // Fetch USUARIOS (existente)
        function fetchUsers(action) { fetch("../php/get_users.php").then(r=>r.ok?r.json():r.text().then(t=>Promise.reject(new Error(`HTTP ${r.status}: ${t}`)))).then(users=>{ if(!Array.isArray(users))throw new Error("Invalid response"); if(action==='view'){let l='<ul>';if(users.length>0)users.forEach(u=>l+=`<li>${u.replace(/</g,"&lt;")}</li>`);else l+='<li>No users</li>';l+='</ul>';showListModal(l,"Usuarios Dominio");} else if(action==='modify'){showModifyUserModal(users);} else if(action==='delete'){showDeleteUserSelectionModal(users);} }).catch(e=>{console.error("fetchUsers:",e);showListModal(`<p style="color:red">Error: ${e.message}</p>`,"Error");}); }

        // Fetch GRUPOS ( *** MODIFICADO para View Members *** )
        function fetchGroups(action='view') {
            fetch("../php/get_groups.php")
            .then(response => { if (!response.ok) return response.text().then(text => Promise.reject(new Error(`HTTP ${response.status}: ${text}`))); return response.json(); })
            .then(groups => {
                // Manejo de posible error devuelto como objeto JSON
                if (typeof groups === 'object' && groups !== null && !Array.isArray(groups) && groups.error) {
                    throw new Error(groups.error);
                }
                if (!Array.isArray(groups)) {
                    throw new Error("Respuesta inválida del servidor al listar grupos.");
                }

                if (action === 'view') {
                    // *** INICIO MODIFICACIÓN: Generar HTML con botón ***
                    let groupListHtml = '<ul>';
                    if(groups.length > 0) {
                        groups.forEach(group => {
                            const safeGroup = group.replace(/</g,"&lt;").replace(/>/g, "&gt;");
                            // Escapar comillas para el onclick attribute
                            const escapedGroup = safeGroup.replace(/'/g, "\\'").replace(/"/g, '&quot;');
                            groupListHtml += `<li>
                                                ${safeGroup}
                                                <button class="view-members-btn" onclick="fetchGroupMembers('${escapedGroup}')">Ver miembros</button>
                                            </li>`;
                        });
                    } else { groupListHtml += '<li>No se encontraron grupos.</li>'; }
                    groupListHtml += '</ul>';
                    // Usa showListModal (definida al final de tu código)
                    showListModal(groupListHtml, "Grupos (Click para ver miembros)");
                     // *** FIN MODIFICACIÓN ***
                } else if (action === 'delete') {
                    showDeleteGroupSelectionModal(groups); // Llama a función existente
                }
                // Podrías añadir action === 'modify' aquí en el futuro
            })
            .catch(e => {
                console.error("fetchGroups:",e);
                // Usa showListModal (definida al final de tu código)
                showListModal(`<p style="color:red">Error al cargar grupos: ${e.message}</p>`, "Error");
             });
        }

        // --- Funciones AJAX (Submit) ---
        // (Incluir aquí las definiciones existentes de submitCreateUserForm, submitEditUserForm, submitCreateGroupForm, submitDeleteUser, submitDeleteGroup)
        function submitCreateUserForm() { const id='create-user-modal'; const f=document.getElementById('create-user-form'); const d=new FormData(f); const m=document.getElementById('create-user-message'); m.textContent='Creando...';m.style.color='';m.style.display='block'; fetch('../php/create_user.php',{method:'POST',body:d}).then(r=>r.json()).then(data=>{showModalMessage(id,data.message||(data.success?'Éxito':'Error'),data.success);if(data.success)f.reset();}).catch(e=>{console.error(e);showModalMessage(id,'Error comunicación.',false);}); }
        function submitEditUserForm() { const id='modify-user-modal'; const f=document.getElementById('edit-user-form'); const d=new FormData(f); const m=document.getElementById('edit-user-message'); m.textContent='Guardando...';m.style.color='';m.style.display='block'; fetch('../php/modify_user.php',{method:'POST',body:d}).then(r=>r.json()).then(data=>{showModalMessage(id,data.message||(data.success?'Éxito':'Error'),data.success);}).catch(e=>{console.error(e);showModalMessage(id,'Error comunicación.',false);}); }
        function submitCreateGroupForm() { const id='create-group-modal'; const f=document.getElementById('create-group-form'); const d=new FormData(f); const m=document.getElementById('create-group-message'); m.textContent='Creando...';m.style.color='';m.style.display='block'; fetch('../php/create_group.php',{method:'POST',body:d}).then(r=>r.json()).then(data=>{showModalMessage(id,data.message||(data.success?'Éxito':'Error'),data.success);if(data.success)f.reset();}).catch(e=>{console.error(e);showModalMessage(id,'Error comunicación',false);}); }
        function submitDeleteUser(username) { const id='delete-user-modal'; const m=document.getElementById('delete-user-message'); if(!m) return; m.innerHTML='<p>Eliminando...</p>';m.style.color='';m.style.display='block'; const d=new FormData(); d.append('username',username); fetch('../php/delete_user.php',{method:'POST',body:d}).then(r=>r.json()).then(data=>{showModalMessage(id,data.message||(data.success?'Eliminado':'Error'),data.success); if(data.success) setTimeout(()=>closeModal(id), 2500); else { const listDiv = document.getElementById('user-delete-selection-list'); if(listDiv) listDiv.style.display = 'block'; } }).catch(e=>{console.error(e);showModalMessage(id,'Error comunicación',false);}); }
        function submitDeleteGroup(groupName) { const id='delete-group-modal'; const m=document.getElementById('delete-group-message'); if(!m) return; m.innerHTML='<p>Eliminando...</p>';m.style.color='';m.style.display='block'; const d=new FormData(); d.append('group_name',groupName); fetch('../php/delete_group.php',{method:'POST',body:d}).then(r=>r.json()).then(data=>{showModalMessage(id,data.message||(data.success?'Eliminado':'Error'),data.success); if(data.success) setTimeout(()=>closeModal(id), 2500); else { const listDiv = document.getElementById('group-delete-selection-list'); if(listDiv) listDiv.style.display = 'block'; } }).catch(e=>{console.error(e);showModalMessage(id,'Error comunicación',false);}); }


        // --- Manejadores de Eventos ---
        // Click en botones de acción principales (existente y correcto para las acciones definidas)
        function handleActionButtonClick(event) {
            const btn = event.target.closest('.action-btn'); if(!btn) return; const action = btn.dataset.action;
            document.querySelectorAll('[id$="-message"]').forEach(div => { div.textContent=''; div.style.display='none'; });
            switch(action){
                case 'create': showCreateUserModal(); break;
                case 'view': fetchUsers('view'); break;
                case 'modify': fetchUsers('modify'); break;
                case 'delete-user': fetchUsers('delete'); break; // Asume que fetchUsers maneja 'delete'
                case 'create-group': showCreateGroupModal(); break;
                case 'view-groups': fetchGroups('view'); break; // Correcto, usa fetchGroups
                case 'delete-group': fetchGroups('delete'); break; // Correcto, usa fetchGroups
                default: console.warn("Acción desconocida:", action);
            }
        }
        // Click Home Link (existente)
        document.getElementById('home-link').addEventListener('click',()=>{ const main=document.getElementById('main-content'); const ifr=main.querySelector('iframe'); if(ifr) ifr.remove(); let home=document.getElementById('dashboard-home'); if(!home){ /* Código para recrear #dashboard-home */ main.innerHTML = `<section class="dashboard-content" id="dashboard-home"><h2>Bienvenido...</h2><p>...</p>...</section>`; document.querySelectorAll('.action-btn').forEach(b => b.addEventListener('click', handleActionButtonClick)); } else { home.style.display = 'block'; /* o flex */ } });
        // Prometheus/Grafana Links (existente)
        document.getElementById("prometheus-link").addEventListener("click", e => { e.preventDefault(); const main=document.getElementById("main-content"); const home=document.getElementById("dashboard-home"); if(home) home.style.display='none'; const old = main.querySelector('iframe'); if(old) old.remove(); main.insertAdjacentHTML('beforeend', '<iframe src="http://192.168.1.6:9090" title="Prometheus" style="width:100%;height:calc(100vh - 60px);border:none;"></iframe>'); });
        document.getElementById("grafana-link").addEventListener("click", e => { e.preventDefault(); const main=document.getElementById("main-content"); const home=document.getElementById("dashboard-home"); if(home) home.style.display='none'; const old = main.querySelector('iframe'); if(old) old.remove(); main.insertAdjacentHTML('beforeend', '<iframe src="http://192.168.1.6:3000" title="Grafana" style="width:100%;height:calc(100vh - 60px);border:none;"></iframe>'); });
        // Theme Toggle (existente)
        document.getElementById('theme-switch').addEventListener('change', function(){ const isDark=this.checked; document.body.classList.toggle('dark-mode', isDark); setCookie('theme',isDark?'dark':'light',30); document.querySelectorAll('.modal').forEach(m=>{ if(m.style.display==='block') m.classList.toggle('dark-mode',isDark); }); });
        // User Dropdown (existente)
        document.getElementById('user-name-btn').addEventListener('click', e => { e.stopPropagation(); document.getElementById('user-dropdown').classList.toggle('show'); });
        window.addEventListener('click', e => { const d=document.getElementById('user-dropdown'); if (d.classList.contains('show') && !e.target.matches('#user-name-btn') && !d.contains(e.target)){ d.classList.remove('show'); } });
        // Close modals on Escape (existente)
        window.addEventListener('keydown', e => { if (e.key==='Escape'){ document.querySelectorAll('.modal').forEach(m => { if(m.style.display==='block') closeModal(m.id); }); const d=document.getElementById('user-dropdown'); if(d.classList.contains('show')) d.classList.remove('show'); } });
        // Initial setup on load (existente)
        document.addEventListener('DOMContentLoaded', () => { document.querySelectorAll('.action-btn').forEach(b => b.addEventListener('click', handleActionButtonClick)); const isDark = getCookie('theme') === 'dark'; document.body.classList.toggle('dark-mode', isDark); document.getElementById('theme-switch').checked = isDark; });


        // --- Bloque de código duplicado/innecesario comentado ---
        /*
        // (Aquí estaba el bloque duplicado que comenté en la respuesta anterior)
        // ...
        */

        // *** NUEVA FUNCIÓN Fetch GROUP MEMBERS (Añadida al final) ***
        function fetchGroupMembers(groupName) {
            const modalTitle = `Miembros de: ${groupName.replace(/</g,"&lt;")}`;
            // Usa la función showListModal definida al final de tu script
            showListModal("<p>Cargando...</p>", modalTitle);

            const formData = new FormData();
            formData.append('group_name', groupName);

            fetch('../php/get_group_members.php', { method: 'POST', body: formData })
            .then(response => {
                // Mejor manejo de errores HTTP antes de .json()
                if (!response.ok) {
                    // Intenta leer el texto del error si existe
                    return response.text().then(text => {
                        throw new Error(`Error HTTP ${response.status}: ${text || response.statusText}`);
                    });
                }
                return response.json();
            })
            .then(members => {
                 // Comprobación robusta de si es un array o un objeto de error devuelto por PHP
                 if (!Array.isArray(members)) {
                     if (typeof members === 'object' && members !== null && members.error) {
                        throw new Error(members.error); // Lanza el error devuelto por PHP
                     }
                    throw new Error("Respuesta inválida del servidor (se esperaba lista de miembros).");
                 }
                 // Generar lista HTML
                 let memberListHtml = '<ul>';
                 if (members.length > 0) {
                     members.forEach(member => memberListHtml += `<li>${member.replace(/</g,"&lt;")}</li>`);
                 } else {
                     memberListHtml += '<li>Este grupo no tiene miembros.</li>';
                 }
                 memberListHtml += '</ul>';
                 // Usa la función showListModal definida al final de tu script
                 showListModal(memberListHtml, modalTitle);
            })
            .catch(error => {
                 console.error("fetchGroupMembers:", error);
                 // Usa la función showListModal definida al final de tu script
                 showListModal(`<p style="color:red">Error: ${error.message}</p>`, `Error Miembros: ${groupName.replace(/</g,"&lt;")}`);
            });
        }

         // Definición de showListModal (tomada del final de tu script)
         // Asegúrate de que esta es la única definición activa si descomentaste el bloque duplicado
         function showListModal(contentHtml, title = "Lista") {
             const modalId = 'generic-list-modal';
             closeModal(modalId);
             const modalHtml = `
                <div id="${modalId}" class="modal ${isDarkMode() ? 'dark-mode' : ''}">
                    <div class="modal-content">
                        <span class="close-btn" onclick="closeModal('${modalId}')">&times;</span>
                        <h3>${title}</h3> ${contentHtml}
                    </div>
                </div>`;
             document.body.insertAdjacentHTML('beforeend', modalHtml);
             document.getElementById(modalId).style.display = "block";
         }


    </script>

</body>
</html>