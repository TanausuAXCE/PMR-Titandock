<?php
header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Error desconocido al crear grupo.'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Recibir datos del formulario JS
    $groupName = $_POST['group_name'] ?? null;
    $groupScope = $_POST['group_scope'] ?? null; // DomainLocal, Global, Universal
    $groupCategory = $_POST['group_category'] ?? null; // Security, Distribution
    $description = $_POST['description'] ?? ''; // Descripción es opcional
    $ouPath = $_POST['path'] ?? null; // Ruta OU es opcional

    // --- Validación básica ---
    if (empty($groupName) || empty($groupScope) || empty($groupCategory)) {
        $response['message'] = 'Error: Nombre, Ámbito y Tipo de grupo son obligatorios.';
        echo json_encode($response);
        exit;
    }
    // Podrías añadir más validaciones (ej: formato de $ouPath si se proporciona)

    // --- Preparar y ejecutar PowerShell ---
    $powershell_script_path = __DIR__ . "/../ps1/create_group.ps1"; // ¡NUEVO SCRIPT PS1!
    $execution_policy = "-ExecutionPolicy Unrestricted"; // O la necesaria

    // Escapar argumentos para seguridad
    $psGroupName_arg = escapeshellarg($groupName);
    $psGroupScope_arg = escapeshellarg($groupScope);
    $psGroupCategory_arg = escapeshellarg($groupCategory);
    $psDescription_arg = escapeshellarg($description);
    // El path es opcional para el comando PS1, solo lo incluimos si no está vacío
    $psPath_arg = !empty($ouPath) ? "-Path " . escapeshellarg($ouPath) : "";

    // Construir comando (usando -File y parámetros nombrados)
    $command = "powershell.exe {$execution_policy} -NoProfile -File \"{$powershell_script_path}\" -GroupName {$psGroupName_arg} -GroupScope {$psGroupScope_arg} -GroupCategory {$psGroupCategory_arg} -Description {$psDescription_arg} {$psPath_arg}";

    // Ejecutar y capturar salida y errores
    $output = shell_exec($command . " 2>&1");

    // --- Interpretar resultado ---
    if ($output !== null && stripos($output, 'SUCCESS:') !== false) {
        $response['success'] = true;
        // Extraer mensaje de éxito del PS1 si es posible
         if (preg_match('/SUCCESS:(.*)/i', $output, $matches)) {
             $response['message'] = trim($matches[1]);
         } else {
            $response['message'] = "Grupo '$groupName' creado correctamente (respuesta genérica).";
         }
    } elseif ($output !== null && stripos($output, 'ERROR:') !== false) {
        $response['success'] = false;
         // Extraer mensaje de error del PS1 si es posible
         if (preg_match('/ERROR:(.*)/i', $output, $matches)) {
             $response['message'] = trim($matches[1]);
         } else {
            $response['message'] = "Error al crear grupo (respuesta genérica). Salida: " . $output;
         }
    } else {
        // Salida inesperada o nula
        $response['success'] = false;
        $response['message'] = "Respuesta inesperada o error al ejecutar el script de creación de grupo. Salida: " . ($output ?: '(Sin salida)');
    }
    // $response['debug_command'] = $command; // Opcional para depurar

} else {
    $response['message'] = 'Error: Método POST requerido.';
}

echo json_encode($response);
exit;
?>