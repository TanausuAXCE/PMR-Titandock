<?php
header('Content-Type: application/json'); // Importante: Indica que la respuesta será JSON

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir los datos del formulario
    $username = $_POST["username"] ?? ""; // Usar ?? para evitar errores si no existe
    $password = $_POST["password"] ?? "";
    $group = $_POST["group"] ?? "";
    $ou = $_POST["ou"] ?? "";

    // Validar los datos (¡MUY IMPORTANTE! - Añade tu propia validación)
    if (empty($username) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Nombre de usuario y contraseña son obligatorios.']);
        exit;
    }

    // Escapar caracteres especiales para seguridad (¡CUIDADO! - Ver notas abajo)
    $username = escapeshellarg($username);
    $password = escapeshellarg($password);
    $group = escapeshellarg($group);
    $ou = escapeshellarg($ou);

    // Ejecutar el script de PowerShell para crear el usuario en AD
    $command = "powershell.exe -ExecutionPolicy Unrestricted -Command -Command \"[Console]::OutputEncoding = [System.Text.UTF8Encoding]::UTF8; & '../ps1/create_user.ps1' '$username' '$password' '$group' '$ou'\"";
    $output = shell_exec($command);

    // Guardar la salida en un archivo (para depuración)
    // file_put_contents('/tmp/powershell_output.txt', $output);

    // O imprimirla en los logs (alternativa)
    error_log("Salida de PowerShell: " . $output);

    // Procesar la salida de PowerShell (¡IMPORTANTE! - Ver notas abajo)
    if (strpos(strtolower($output), "creado correctamente") !== false) {
        echo json_encode(['success' => true, 'message' => "Usuario creado correctamente.", 'debug' => $output]); // Añadido para depuración
    } else {
        echo json_encode(['success' => false, 'message' => "Error: " . $output, 'debug' => $output]); // Incluir la salida completa
    }

} else {
    // Si no es una petición POST, devolver un error
    echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
}
?>