# Definir parámetros que acepta el script
param(
    [Parameter(Mandatory=$true)]
    [string]$GroupName,          # Nombre del grupo (SamAccountName)

    [Parameter(Mandatory=$true)]
    [ValidateSet("DomainLocal", "Global", "Universal")] # Asegura valores válidos
    [string]$GroupScope,         # Ámbito: DomainLocal, Global, Universal

    [Parameter(Mandatory=$true)]
    [ValidateSet("Security", "Distribution")] # Asegura valores válidos
    [string]$GroupCategory,      # Tipo: Security, Distribution

    [Parameter(Mandatory=$false)] # Opcional
    [string]$Description = "",   # Descripción

    [Parameter(Mandatory=$false)] # Opcional
    [string]$Path               # Ruta OU donde crear el grupo
)

# Importar módulo AD
try {
    Import-Module ActiveDirectory -ErrorAction Stop
}
catch {
    Write-Host "ERROR: No se pudo importar el módulo ActiveDirectory."
    exit 1
}

# Construir los parámetros para New-ADGroup
$newGroupParams = @{
    Name           = $GroupName
    GroupScope     = $GroupScope
    GroupCategory  = $GroupCategory
    Description    = $Description
    SamAccountName = $GroupName # Usar el mismo nombre para SamAccountName
    # El parámetro Path solo se añade si se proporcionó
}
if ($PSBoundParameters.ContainsKey('Path')) {
    if (-not ([string]::IsNullOrEmpty($Path))) {
         # Validar que el path exista podría ser buena idea aquí, pero lo dejamos simple por ahora
        $newGroupParams.Path = $Path
    }
}

# Intentar crear el grupo
try {
    New-ADGroup @newGroupParams -ErrorAction Stop
    Write-Host "SUCCESS: Grupo '$GroupName' creado correctamente."
    exit 0
}
catch {
    # Capturar error específico de New-ADGroup
    $errorMessage = $_.Exception.Message
    # Comprobar si el error es porque ya existe
    if ($errorMessage -like "*The specified group already exists*") {
         Write-Host "ERROR: El grupo '$GroupName' ya existe."
    }
    else {
         Write-Host "ERROR: Fallo al crear el grupo '$GroupName'. Detalles: $errorMessage"
    }
    exit 1
}