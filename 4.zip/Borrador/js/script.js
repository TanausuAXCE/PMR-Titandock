document.addEventListener("DOMContentLoaded", function () {
    setTimeout(() => {
        window.location.href = "../php/login.php"; // Redirigir a la página de inicio de sesión
    }, 5000); // 5 segundos de espera
});
