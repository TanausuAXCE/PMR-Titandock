<?php
session_start(); // Inicia la sesión

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    header("Location: ../pages/login.php"); // Redirige si no está autenticado
    exit();
}

$username = $_SESSION['usuario']; // Obtén el nombre del usuario desde la sesión
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TitanDock - Dashboard</title>
    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo">
                <img src="../assets/logo.png" alt="Logo TitanDock" id="logo">
                <span class="logo-text">TitanDock</span> 
            </div>
            <ul class="navbar-right">
                <li class="theme-toggle">
                    <label for="theme-switch" class="switch">
                        <input type="checkbox" id="theme-switch">
                        <span class="slider"></span>
                    </label>
                </li>
                <li><a href="https://prometheus.io" target="_blank">Prometheus</a></li>
                <li><a href="https://grafana.com" target="_blank">Grafana</a></li>
                <li class="user-info">
                    <button id="user-name-btn" class="user-btn">
                        <?php echo htmlspecialchars($username); ?> <!-- Mostrar el nombre del usuario -->
                    </button>
                    <div id="user-dropdown" class="dropdown-content">
                        <a href="../php/logout.php">Cerrar Sesión</a>
                    </div>
                </li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="dashboard-content">
            <h2>Bienvenido, <?php echo htmlspecialchars($username); ?>!</h2>
            <p>Aquí puedes gestionar tu aplicación y visualizar métricas.</p>
        </section>
    </main>

    <script src="../js/dashboard.js"></script>
</body>
</html>
