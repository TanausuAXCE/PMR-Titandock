<?php
header('Content-Type: application/json');
$response = ['success' => false, 'message' => 'Error desconocido al eliminar usuario.'];

// Solo permitir método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'] ?? null;

    if (empty($username)) {
        $response['message'] = 'Error: Nombre de usuario no proporcionado.';
    } else {
        // --- Ejecutar PowerShell ---
        $powershell_script_path = __DIR__ . "/../ps1/delete_user.ps1"; // ¡NUEVO SCRIPT PS1!
        $execution_policy = "-ExecutionPolicy Unrestricted"; // O la necesaria

        // Escapar argumento
        $psUsername_arg = escapeshellarg($username);

        // Construir y ejecutar comando
        $command = "powershell.exe {$execution_policy} -NoProfile -File \"{$powershell_script_path}\" -SamAccountName {$psUsername_arg}";
        $output = shell_exec($command . " 2>&1"); // Capturar salida y errores

        // --- Interpretar resultado ---
        if ($output !== null && stripos($output, 'SUCCESS:') !== false) {
            $response['success'] = true;
            $response['message'] = "Usuario '$username' eliminado correctamente.";
             // Podrías extraer el mensaje SUCCESS exacto si quieres:
             // preg_match('/SUCCESS:(.*)/i', $output, $matches);
             // $response['message'] = trim($matches[1] ?? "Usuario '$username' eliminado.");

        } elseif ($output !== null && stripos($output, 'ERROR:') !== false) {
            $response['success'] = false;
             // Extraer mensaje de error
             preg_match('/ERROR:(.*)/i', $output, $matches);
             $response['message'] = trim($matches[1] ?? "Error al eliminar usuario '$username'.");
        } else {
            // Salida inesperada o nula
            $response['success'] = false;
            $response['message'] = "Respuesta inesperada del script al eliminar usuario '$username'. Salida: " . ($output ?: '(Sin salida)');
        }
        // $response['debug_command'] = $command; // Para depuración
        // $response['debug_output'] = $output; // Para depuración
    }

} else {
    $response['message'] = 'Error: Método POST requerido.';
}

echo json_encode($response);
exit;
?>