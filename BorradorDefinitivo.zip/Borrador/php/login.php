<?php
session_start();
require '../php/db.php'; // Conexión a la base de datos

// Verificar si se envió un formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['login'])) {
        // --- PROCESO DE INICIO DE SESIÓN ---
        $usuario = $conn->real_escape_string($_POST['login-user']);
        $password = $_POST['login-pass'];

        // Buscar usuario en la base de datos
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            // Verificar la contraseña
            if (password_verify($password, $row['password'])) {
                $_SESSION['usuario'] = $row['username'];
                header("Location: ../php/dashboard.php");
                exit;
            } else {
                echo "<script>alert('Contraseña incorrecta.');</script>";
            }
        } else {
            echo "<script>alert('Usuario no encontrado.');</script>";
        }
    }

    if (isset($_POST['register'])) {
        // --- PROCESO DE REGISTRO ---
        $usuario = $conn->real_escape_string($_POST['register-user']);
        $email = $conn->real_escape_string($_POST['register-email']);
        $password = password_hash($_POST['register-pass'], PASSWORD_DEFAULT);

        // Verificar si el usuario ya existe
        $checkUser = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $checkUser->bind_param("s", $usuario);
        $checkUser->execute();
        $checkUser->store_result();

        if ($checkUser->num_rows > 0) {
            echo "<script>alert('El usuario ya existe.');</script>";
        } else {
            // Insertar nuevo usuario
            $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $usuario, $email, $password);

            if ($stmt->execute()) {
                echo "<script>alert('Registro exitoso. Ahora puedes iniciar sesión.');</script>";
            } else {
                echo "<script>alert('Error al registrar usuario.');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TitanDock - Iniciar Sesión</title>
    <link rel="stylesheet" href="../css/login.css">
</head>
<body>
    <div class="login-container">
        <div class="tabs">
            <button id="login-tab" class="active" onclick="showLogin()">Iniciar Sesión</button>
            <button id="register-tab" onclick="showRegister()">Registrarse</button>
        </div>

        <!-- Formulario de Inicio de Sesión -->
        <div id="login-form">
            <h2>Iniciar Sesión</h2>
            <form method="POST">
                <input type="text" name="login-user" placeholder="Usuario" required>
                <input type="password" name="login-pass" placeholder="Contraseña" required>
                
                <div class="checkbox-container">
                    <input type="checkbox" id="remember-me">
                    <label for="remember-me">Recuérdame</label>
                </div>

                <button type="submit" name="login">Ingresar</button>
            </form>
        </div>

        <!-- Formulario de Registro -->
        <div id="register-form" class="hidden">
            <h2>Registrarse</h2>
            <form method="POST">
                <input type="text" name="register-user" placeholder="Usuario" required>
                <input type="email" name="register-email" placeholder="Correo Electrónico" required>
                <input type="password" name="register-pass" placeholder="Contraseña" required>

                <div class="checkbox-container">
                    <input type="checkbox" id="terms" required>
                    <label for="terms">
                        Acepto los 
                        <a href="../pages/terms.html" target="_blank">Términos y Condiciones</a>
                    </label>
                </div>

                <button type="submit" name="register">Registrarse</button>
            </form>
        </div>
    </div>

    <script>
        function showLogin() {
            document.getElementById("login-form").classList.remove("hidden");
            document.getElementById("register-form").classList.add("hidden");
        }

        function showRegister() {
            document.getElementById("login-form").classList.add("hidden");
            document.getElementById("register-form").classList.remove("hidden");
        }
    </script>
</body>
</html>
