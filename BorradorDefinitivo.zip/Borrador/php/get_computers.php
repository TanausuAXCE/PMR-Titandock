<?php
// No establecer Content-Type aquí, se hará después

$response = []; // Respuesta por defecto

// --- Ejecutar PowerShell ---
$powershell_script_path = __DIR__ . "/../ps1/get_computers.ps1"; // ¡NUEVO SCRIPT PS1!
$execution_policy = "-ExecutionPolicy Unrestricted";

// Construir y ejecutar comando
$command = "powershell.exe {$execution_policy} -NoProfile -File \"{$powershell_script_path}\"";
$output = shell_exec($command . " 2>&1");
error_log("SALIDA BRUTA de get_computers.ps1: " . $output); // Log para depuración

// --- Procesar resultado ---
$computers = [];
$error_detected = false;

if ($output === null) {
    $response = ['error' => 'Error interno del servidor al ejecutar script de equipos.'];
    $error_detected = true;
    if (!headers_sent()) header('HTTP/1.1 500 Internal Server Error');
} else {
    $lines = preg_split('/\r\n|\r|\n/', trim($output));
    foreach ($lines as $line) {
        $trimmed_line = trim($line);
        if (stripos($trimmed_line, 'ERROR:') !== false) {
            preg_match('/ERROR:(.*)/i', $trimmed_line, $matches);
            $response = ['error' => trim($matches[1] ?? 'Error detectado en script PowerShell.')];
            $error_detected = true;
             if (!headers_sent()) header('HTTP/1.1 500 Internal Server Error');
            break;
        }
        if (!empty($trimmed_line)) {
            $computers[] = $trimmed_line;
        }
    }
    if (!$error_detected) {
        $response = $computers; // Respuesta es la lista de equipos
    }
}

// --- Codificar y Enviar ---
if (!headers_sent()) {
    header('Content-Type: application/json'); // Enviar cabecera JSON ahora
}

$json_output = json_encode($response, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_IGNORE);

if ($json_output === false) {
    $json_error_code = json_last_error(); $json_error_msg = json_last_error_msg();
    error_log("ERROR: json_encode falló en get_computers.php. Código: {$json_error_code}, Mensaje: {$json_error_msg}");
    if (!headers_sent()) { header('HTTP/1.1 500 Internal Server Error'); header('Content-Type: application/json'); }
    echo json_encode(['error' => "Fallo al codificar JSON (Error code: {$json_error_code})"]);
} else {
    echo $json_output;
}
exit;
?>