# Definir parámetro obligatorio
param(
    [Parameter(Mandatory=$true)]
    [string]$SamAccountName
)

# Importar módulo AD
try {
    Import-Module ActiveDirectory -ErrorAction Stop
}
catch {
    Write-Host "ERROR: No se pudo importar el módulo ActiveDirectory."
    exit 1
}

# Intentar obtener el usuario para confirmar que existe antes de borrar
try {
    $user = Get-ADUser -Identity $SamAccountName -ErrorAction Stop
}
catch {
    Write-Host "ERROR: Usuario '$SamAccountName' no encontrado."
    exit 1
}

# Intentar eliminar el usuario
# -Confirm:$false es VITAL para que no pida confirmación interactiva
try {
    Remove-ADUser -Identity $SamAccountName -Confirm:$false -ErrorAction Stop
    Write-Host "SUCCESS: Usuario '$SamAccountName' eliminado permanentemente."
    exit 0
}
catch {
    $errorMessage = $_.Exception.Message
    Write-Host "ERROR: Fallo al eliminar el usuario '$SamAccountName'. Detalles: $errorMessage"
    exit 1
}