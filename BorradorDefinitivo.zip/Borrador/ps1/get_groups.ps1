# No necesita parámetros para listar todos los grupos por defecto

# Importar módulo AD
try {
    Import-Module ActiveDirectory -ErrorAction Stop
}
catch {
    Write-Host "ERROR: No se pudo importar el módulo ActiveDirectory."
    exit 1 # Salir si falla la importación
}

# Obtener y mostrar los nombres de los grupos
try {
    # Obtener solo el nombre (SamAccountName es generalmente mejor para identificadores únicos)
    # Puedes cambiar a Name si prefieres el nombre descriptivo.
    $groups = Get-ADGroup -Filter * -ErrorAction Stop | Select-Object -ExpandProperty SamAccountName

    # Imprimir cada nombre de grupo en una nueva línea
    # Esto es lo que leerá el PHP con explode("\n", ...)
    if ($groups) {
        $groups | ForEach-Object { Write-Host $_ }
    }
    # Si no hay grupos, no se imprimirá nada (PHP obtendrá un array vacío, lo cual está bien)

    exit 0 # Éxito
}
catch {
    $errorMessage = $_.Exception.Message
    Write-Host "ERROR: Fallo al obtener la lista de grupos. Detalles: $errorMessage"
    exit 1 # Error
}