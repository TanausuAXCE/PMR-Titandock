# Definir los parámetros que el script aceptará desde la línea de comandos
param(
    [Parameter(Mandatory=$true)]
    [string]$SamAccountName,  # Nombre de usuario a modificar

    [Parameter(Mandatory=$true)]
    [string]$PropertyName,    # Propiedad a cambiar (ej: Description, Title)

    [Parameter(Mandatory=$true)]
    [string]$NewValue         # Nuevo valor para la propiedad
)

# Importar módulo de Active Directory (añadir try/catch si es necesario)
try {
    Import-Module ActiveDirectory -ErrorAction Stop
}
catch {
    Write-Host "ERROR: No se pudo importar el módulo ActiveDirectory. ¿Está instalado en el servidor?"
    exit 1 # Código de salida distinto de 0 indica error
}

# Lista de propiedades permitidas para modificar desde este script (¡IMPORTANTE!)
# Asegúrate que coincide o incluye las que pones en el formulario HTML/PHP
$allowedProperties = @("DisplayName", "Title", "Department", "Description", "OfficePhone", "MobilePhone")

# Validar que la propiedad solicitada esté permitida
if ($PropertyName -notin $allowedProperties) {
    Write-Host "ERROR: La propiedad '$PropertyName' no está permitida para modificación o no es válida."
    exit 1
}

# Intentar obtener el usuario
try {
    $user = Get-ADUser -Identity $SamAccountName -ErrorAction Stop
}
catch {
    Write-Host "ERROR: Usuario '$SamAccountName' no encontrado."
    exit 1
}

# Intentar aplicar el cambio
try {
    # Usar -Replace para asegurar que la propiedad se actualiza
    Set-ADUser -Identity $SamAccountName -Replace @{$PropertyName = $NewValue} -ErrorAction Stop
    # Si llega aquí, tuvo éxito
    Write-Host "SUCCESS: Propiedad '$PropertyName' del usuario '$SamAccountName' modificada correctamente."
    exit 0 # Código de salida 0 indica éxito
}
catch {
    # Capturar cualquier error durante Set-ADUser
    $errorMessage = $_.Exception.Message
    Write-Host "ERROR: Fallo al modificar la propiedad '$PropertyName' para '$SamAccountName'. Detalles: $errorMessage"
    exit 1
}