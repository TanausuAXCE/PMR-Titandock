# No necesita parámetros para listar todos los equipos por defecto

# Importar módulo AD
try {
    Import-Module ActiveDirectory -ErrorAction Stop
}
catch {
    Write-Host "ERROR: No se pudo importar el módulo ActiveDirectory."
    exit 1
}

# Obtener y mostrar los nombres de los equipos
try {
    # Obtener el nombre DNS (o Name/SamAccountName si prefieres)
    $computers = Get-ADComputer -Filter * -ErrorAction Stop | Select-Object -ExpandProperty Name

    # Imprimir cada nombre de equipo en una nueva línea
    if ($computers) {
        $computers | ForEach-Object { Write-Host $_ }
    }

    # Podríamos añadir SUCCESS aquí si quisiéramos, pero la lista vacía es éxito también
    exit 0
}
catch {
    $errorMessage = $_.Exception.Message
    Write-Host "ERROR: Fallo al obtener la lista de equipos. Detalles: $errorMessage"
    exit 1
}