param (
    [string]$UserName,
    [string]$Fields
)

# Establecer la codificación de entrada y salida a UTF-8 para manejar caracteres especiales
$OutputEncoding = [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding

# Asegurarse de que el script termine si hay un error
$ErrorActionPreference = "Stop"

# Depuración - Verificar los parámetros
Write-Host "Usuario recibido: $UserName"
Write-Host "Campos a modificar: $Fields"

# Verificar si el usuario existe
try {
    $user = Get-ADUser -Identity $UserName -Properties DisplayName, EmailAddress, Title
    if ($null -eq $user) {
        Write-Host "El usuario '$UserName' no existe en el dominio."
        exit 1
    }
    Write-Host "Usuario encontrado: $($user.SamAccountName)"
} catch {
    Write-Host "Error al obtener los datos del usuario: $_"
    exit 1
}

# Dividir los campos a modificar en un array
$fieldsToModify = $Fields.Split(',')

# Modificar los campos seleccionados
foreach ($field in $fieldsToModify) {
    switch ($field) {
        "displayname" {
            $newDisplayName = Read-Host "Ingrese el nuevo nombre completo"
            Set-ADUser -Identity $UserName -DisplayName $newDisplayName
            Write-Host "Nombre completo de '$UserName' actualizado a '$newDisplayName'."
        }
        "email" {
            $newEmail = Read-Host "Ingrese el nuevo correo electrónico"
            Set-ADUser -Identity $UserName -EmailAddress $newEmail
            Write-Host "Correo electrónico de '$UserName' actualizado a '$newEmail'."
        }
        "title" {
            $newTitle = Read-Host "Ingrese el nuevo título"
            Set-ADUser -Identity $UserName -Title $newTitle
            Write-Host "Título de '$UserName' actualizado a '$newTitle'."
        }
        default {
            Write-Host "Campo '$field' no válido."
        }
    }
}

Write-Host "Modificación completada para el usuario '$UserName'."
