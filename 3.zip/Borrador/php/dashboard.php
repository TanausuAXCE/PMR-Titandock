<?php
session_start(); // Inicia la sesión

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    header("Location: ../pages/login.php"); // Redirige si no está autenticado
    exit();
}

$username = $_SESSION['usuario']; // Obtén el nombre del usuario desde la sesión
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TitanDock - Dashboard</title>
    <link rel="stylesheet" href="../css/dashboard.css">
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        main {
            flex: 1;
            overflow: auto;
            padding-top: 60px; /* Ajusta según la altura del header */
        }
        iframe {
            width: 100%;
            height: calc(100vh - 60px); /* Resta la altura del header */
            border: none;
        }

        /* Estilo para la caja del objetivo */
        .action-box {
            width: 300px;
            padding: 20px;
            margin: 20px auto;
            background-color: #f4f4f4;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .action-box h3 {
            margin-bottom: 15px;
            font-size: 18px;
            color: #333;
        }

        .action-box button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .action-box button:hover {
            background-color: #0056b3;
 /* Estilo para el modal */
 .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
    }

    .modal-content {
        background-color: #fff;
        margin: 10% auto;
        padding: 20px;
        border-radius: 8px;
        width: 80%;
        max-width: 600px;
        position: relative;
    }

    .close-btn {
        position: absolute;
        top: 10px;
        right: 10px;
        font-size: 30px;
        color: #000;
        cursor: pointer;
    }

    .close-btn:hover {
        color: #f00;
    }

    ul {
        list-style-type: none;
        padding: 0;
    }

    li {
        padding: 5px 0;
        font-size: 16px;
    }
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="logo" id="home-link" style="cursor: pointer;">
                <img src="../assets/logo.png" alt="Logo TitanDock" id="logo">
                <span class="logo-text">TitanDock</span> 
            </div>
            <ul class="navbar-right">
                <li class="theme-toggle">
                    <label for="theme-switch" class="switch">
                        <input type="checkbox" id="theme-switch">
                        <span class="slider"></span>
                    </label>
                </li>
                <li><a href="#" id="prometheus-link">Prometheus</a></li>
                <li><a href="#" id="grafana-link">Grafana</a></li>
                <li class="user-info">
                    <button id="user-name-btn" class="user-btn">
                        <?php echo htmlspecialchars($username); ?> <!-- Mostrar el nombre del usuario -->
                    </button>
                    <div id="user-dropdown" class="dropdown-content">
                        <a href="../php/logout.php">Cerrar Sesión</a>
                    </div>
                </li>
            </ul>
        </nav>
    </header>

    <main id="main-content">
        <section class="dashboard-content">
            <h2>Bienvenido, <?php echo htmlspecialchars($username); ?>!</h2>
            <p>Aquí puedes gestionar tu aplicación y visualizar métricas.</p>
            
            <!-- Caja para la acción "Crear usuario" -->
            <div class="action-box">
                <h3>Crear usuario en el dominio</h3>
                <button id="create-user-btn">Crear usuario</button>
            </div>
            <div class="action-box">
              <h3>Ver usuarios en el dominio</h3>
              <button id="get-users-btn">Ver usuarios</button>
            </div>
            <div class="action-box">
                <h3>Modificar usuario en el dominio</h3>
                <button id="modify-user-btn">Modificar usuario</button>
            </div>

        </section>
    </main>

    <script>
        // Evento que maneja el clic en el botón "Crear usuario"
        document.getElementById("create-user-btn").addEventListener("click", function() {
            // Redirige a create_user.php para manejar la creación del usuario
            window.location.href = "../php/create_user.php"; // Ruta hacia el archivo PHP
        });

        document.getElementById("get-users-btn").addEventListener("click", function() {
        // Realizar una solicitud AJAX para obtener los usuarios
        fetch("../php/get_users.php")
            .then(response => response.json())  // Convertir la respuesta en JSON
            .then(users => {
                // Crear una cadena HTML para mostrar los usuarios en el popup
                let userListHtml = '<ul>';
                users.forEach(user => {
                    userListHtml += `<li>${user}</li>`;
                });
                userListHtml += '</ul>';

                // Mostrar el popup con los usuarios
                showModal(userListHtml);
            })
            .catch(error => {
                console.error("Error al obtener los usuarios:", error);
                alert("Ocurrió un error al obtener los usuarios.");
            });
            });
        
        // Función para mostrar el modal
        function showModal(content) {
            // Crear el HTML para el modal
            const modalHtml = `
                <div id="user-modal" class="modal">
                    <div class="modal-content">
                        <span class="close-btn" onclick="closeModal()">&times;</span>
                        <h3>Usuarios del dominio</h3>
                        ${content}
                    </div>
                </div>
            `;

            // Añadir el modal al body
            document.body.insertAdjacentHTML('beforeend', modalHtml);

            // Mostrar el modal
            document.getElementById("user-modal").style.display = "block";
        }

        // Función para cerrar el modal
        function closeModal() {
            const modal = document.getElementById("user-modal");
            modal.style.display = "none";
            modal.remove();
        }
        document.getElementById("modify-user-btn").addEventListener("click", function() {
        // Realizar una solicitud AJAX para obtener los usuarios
        fetch("../php/get_users.php")
            .then(response => response.json())  // Convertir la respuesta en JSON
            .then(users => {
                // Crear una cadena HTML para mostrar los usuarios en el popup
                let userListHtml = '<ul>';
                users.forEach(user => {
                    userListHtml += `<li><button class="select-user-btn" data-username="${user}">${user}</button></li>`;
                });
                userListHtml += '</ul>';

                // Mostrar el popup con los usuarios
                showModifyUserModal(userListHtml);
            })
            .catch(error => {
                console.error("Error al obtener los usuarios:", error);
                alert("Ocurrió un error al obtener los usuarios.");
            });
    });

    // Función para mostrar el modal de selección de usuario
    function showModifyUserModal(content) {
        const modalHtml = `
            <div id="modify-user-modal" class="modal">
                <div class="modal-content">
                    <span class="close-btn" onclick="closeModal()">&times;</span>
                    <h3>Seleccionar usuario para modificar</h3>
                    ${content}
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        document.getElementById("modify-user-modal").style.display = "block";

        // Añadir evento a cada botón de usuario
        const userButtons = document.querySelectorAll(".select-user-btn");
        userButtons.forEach(button => {
            button.addEventListener("click", function() {
                const username = button.getAttribute("data-username");
                showUserEditForm(username); // Mostrar el formulario de edición para el usuario seleccionado
            });
        });
    }

    // Función para mostrar el formulario de edición de usuario
    function showUserEditForm(username) {
        // Realizar una solicitud AJAX para obtener los datos del usuario
        fetch(`../php/get_user_data.php?username=${username}`)
            .then(response => response.json())
            .then(userData => {
                const formHtml = `
                    <div id="edit-user-form">
                        <h3>Modificar usuario: ${username}</h3>
                        <form id="modify-form">
                            <label for="new-username">Nuevo nombre de usuario:</label>
                            <input type="text" id="new-username" name="new-username" value="${userData.username}">
                            <label for="new-email">Nuevo correo electrónico:</label>
                            <input type="email" id="new-email" name="new-email" value="${userData.email}">
                            <label for="new-role">Nuevo rol:</label>
                            <input type="text" id="new-role" name="new-role" value="${userData.role}">
                            <button type="submit">Guardar cambios</button>
                        </form>
                        <button onclick="closeModal()">Cerrar</button>
                    </div>
                `;

                // Añadir el formulario al modal
                document.body.insertAdjacentHTML('beforeend', formHtml);

                // Mostrar el modal de edición
                document.getElementById("edit-user-form").style.display = "block";

                // Manejar la sumisión del formulario
                document.getElementById("modify-form").addEventListener("submit", function(event) {
                    event.preventDefault(); // Prevenir recarga de página
                    const newUsername = document.getElementById("new-username").value;
                    const newEmail = document.getElementById("new-email").value;
                    const newRole = document.getElementById("new-role").value;

                    // Enviar la solicitud de modificación al servidor
                    fetch("../php/modify_user.php", {
                        method: "POST",
                        body: JSON.stringify({
                            username: username, // Usuario original
                            newUsername: newUsername,
                            newEmail: newEmail,
                            newRole: newRole
                        }),
                        headers: {
                            "Content-Type": "application/json"
                        }
                    })
                    .then(response => response.json())
                    .then(result => {
                        alert(result.message); // Mostrar mensaje de éxito o error
                        closeModal(); // Cerrar el modal
                    })
                    .catch(error => {
                        console.error("Error al modificar usuario:", error);
                        alert("Ocurrió un error al modificar el usuario.");
                    });
                });
            })
            .catch(error => {
                console.error("Error al obtener los datos del usuario:", error);
                alert("Ocurrió un error al obtener los datos del usuario.");
            });
    }


        document.getElementById("prometheus-link").addEventListener("click", function(event) {
            event.preventDefault(); // Evita que el enlace redirija
            const mainContent = document.getElementById("main-content");
            mainContent.innerHTML = '<iframe src="http://192.168.1.6:9090"></iframe>';
        });

        document.getElementById("grafana-link").addEventListener("click", function(event) {
            event.preventDefault(); // Evita que el enlace redirija
            const mainContent = document.getElementById("main-content");
            mainContent.innerHTML = '<iframe src="http://192.168.1.6:3000"></iframe>';
        });

        

    </script>
    
    <script src="../js/dashboard.js"></script>
</body>
</html>
