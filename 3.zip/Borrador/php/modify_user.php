<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibir los datos del formulario
    $username = $_POST["username"];
    $fieldsToModify = $_POST["fields"] ?? []; // Campos seleccionados a modificar (puede ser un array)

    // Escapar caracteres especiales para seguridad
    $username = escapeshellarg($username);

    // Convertir el array de campos a un string para pasarlo al PowerShell
    $fields = implode(",", $fieldsToModify);

    // Ejecutar el script de PowerShell para modificar el usuario en AD
    $command = "powershell.exe -ExecutionPolicy Unrestricted -Command -Command \"[Console]::OutputEncoding = [System.Text.UTF8Encoding]::UTF8; & '../ps1/modify_user.ps1' '$username' '$fields'\"";
    $output = shell_exec($command);

    // Mostrar el resultado en la página
    echo "<pre>$output</pre>";
    
    echo "<br><a href='dashboard.php'>Volver</a>"; // Volver al formulario
} else {
    // Si no se ha enviado el formulario, mostrarlo
    include 'form.php';
}
?>